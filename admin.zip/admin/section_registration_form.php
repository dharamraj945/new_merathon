<?php

echo "section_registration_form";
