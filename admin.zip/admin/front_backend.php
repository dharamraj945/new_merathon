<?php
include "./config/session_manage.php";
include "./config/class.php";

if ($_SERVER['REQUEST_METHOD'] == "POST") {

    if (isset($_POST['section_id'])) {

        $section_id = $_POST['section_id'];

        $qry = "";
    }
}
