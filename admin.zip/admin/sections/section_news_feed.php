<?php

echo "section_news_feed";
