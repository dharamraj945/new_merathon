<?php

echo "section_event_details";
